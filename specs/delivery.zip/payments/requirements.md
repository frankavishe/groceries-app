# Payments — Requirements

Source: `grocery_app_specifications.pdf` §3A/§3B (USSD Push, real-time status polling, webhook signature verification), §4 (`POST /payments/initiate`, `POST /payments/callback/:provider`). Highest external-dependency risk in the system — see [[../constitution]] for the adapter-isolation and idempotency invariants this module must follow.

## User Story: As a customer, I want to trigger a mobile money payment for my order.

1. WHEN an authenticated `CUSTOMER` calls `POST /api/v1/payments/initiate` with `order_id`, `provider` (one of `MPESA`/`MIXX_BY_YAS`/`AIRTEL_MONEY`), and `phone_number`, THE SYSTEM SHALL create a `payment_transactions` row (`status = INITIATED`) and trigger a USSD push via that provider's adapter.
2. IF the target order is not in `PENDING` status (e.g. already `PAID` or `CANCELLED`), THEN THE SYSTEM SHALL reject the initiate request with 400.
3. IF the requested `amount` to charge does not match the order's `total_amount`, THEN THE SYSTEM SHALL reject — the amount is always derived server-side from the order, never accepted from the client.
4. WHEN a customer retries payment for the same still-`PENDING` order (e.g. after a failed attempt), THE SYSTEM SHALL allow a new `payment_transactions` row for that order rather than reusing/mutating the failed one, so the failure history is preserved.

## User Story: As the system, I need to receive and trust payment completion callbacks from mobile network operators.

5. WHEN `POST /api/v1/payments/callback/:provider` receives a request, THE SYSTEM SHALL verify its authenticity using that provider's specific verification mechanism (signature header, shared secret, or equivalent) BEFORE reading or trusting the payload.
6. IF signature verification fails, THEN THE SYSTEM SHALL reject with 401 and SHALL NOT modify any `payment_transactions` or `orders` row.
7. WHEN a callback is verified and indicates success, THE SYSTEM SHALL set the matching `payment_transactions.status = SUCCESSFUL` and cascade the associated order's `status` to `PAID`.
8. WHEN a callback is verified and indicates failure, THE SYSTEM SHALL set `payment_transactions.status = FAILED`; the order remains `PENDING` (still reservable/retryable until the 20-minute timeout in [[../orders/requirements]] Req 5).
9. WHEN the same callback (same `reference_id`/`checkout_request_id`) is received more than once, THE SYSTEM SHALL process it idempotently — the second delivery SHALL NOT double-apply the status change or error out destructively.
10. THE SYSTEM SHALL store the complete raw callback payload in `payment_transactions.response_payload` regardless of outcome.

## User Story: As a customer, I want to check on my payment's status while waiting.

11. WHEN a client calls `GET /api/v1/payments/:orderId/status`, THE SYSTEM SHALL return the current `payment_transactions.status` for that order's most recent payment attempt.

## User Story: As an admin, I want visibility into all transactions.

12. WHEN an authenticated `ADMIN` calls `GET /api/v1/payments/transactions`, THE SYSTEM SHALL return a paginated, filterable (by `provider`, `status`) list of transactions.
13. WHEN an authenticated `ADMIN` calls `GET /api/v1/payments/summary`, THE SYSTEM SHALL return transaction count and amount totals grouped by `payment_provider`.
