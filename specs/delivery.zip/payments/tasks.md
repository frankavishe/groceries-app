# Payments — Tasks

- [ ] Define `PaymentProviderAdapter` interface in `/backend/src/payments`. (supports all)
- [ ] Implement `POST /payments/initiate`: validate order status, derive amount server-side, create transaction row, call adapter. (Req 1–4)
- [ ] Implement M-Pesa adapter against sandbox docs; document its verification mechanism in [[design]]. (Req 1, 5 — reference adapter, `PLAN.md` M7)
- [ ] Implement `POST /payments/callback/:provider` dispatcher with signature verification before any DB write. (Req 5–6)
- [ ] Implement idempotent callback processing keyed on `reference_id`/`checkout_request_id`. (Req 9)
- [ ] Implement success/failure status cascade to `orders.status` via the shared transition-table mechanism from [[../orders/design]]. (Req 7–8)
- [ ] Store raw payload on every callback outcome. (Req 10)
- [ ] Implement Mixx by Yas adapter; document its verification mechanism. (`PLAN.md` M9)
- [ ] Implement Airtel Money adapter; document its verification mechanism. (`PLAN.md` M9)
- [ ] Implement `GET /payments/:orderId/status`. (Req 11)
- [ ] Implement `GET /payments/transactions` (admin, paginated/filterable). (Req 12)
- [ ] Implement `GET /payments/summary` (admin, grouped by provider). (Req 13)
- [ ] Write a duplicate-callback replay test confirming idempotency. (Req 9)
- [ ] Update `/docs` OpenAPI, flagging the 3 admin/polling additions beyond the spec PDF's original list.
