# Payments — Design

Implements [[requirements]]. Built last per `PLAN.md` Phase 9 — isolated from Orders via the adapter interface below so no other module's progress depends on real MNO sandbox access.

## Endpoints

| Method | Path | Access | Notes |
|---|---|---|---|
| POST | `/api/v1/payments/initiate` | Customer | Req 1–4, in the spec PDF's original list |
| POST | `/api/v1/payments/callback/:provider` | Webhook (no JWT — verified by provider signature instead) | Req 5–10, in the spec PDF's original list |
| GET | `/api/v1/payments/:orderId/status` | Customer (own order) | Req 11, addition for mobile polling |
| GET | `/api/v1/payments/transactions` | Admin | Req 12, addition for admin-web |
| GET | `/api/v1/payments/summary` | Admin | Req 13, addition for admin-web |

## PaymentProviderAdapter (per [[../constitution]])

```
interface PaymentProviderAdapter {
  initiate(order, phoneNumber): Promise<{ checkoutRequestId, referenceId }>;
  verifyCallback(rawRequest): boolean;
  parseCallback(rawRequest): { referenceId, checkoutRequestId, status: 'SUCCESSFUL' | 'FAILED', raw: object };
}
```
One implementation per provider under `/backend/src/payments/adapters/{mpesa,mixx-yas,airtel-money}/`. The Payments Engine (`payments.service.ts`) only calls this interface — no provider-specific branching outside the adapter files.

## Initiate Flow (Req 1–4)

1. Load the order; verify `status = PENDING` (Req 2) and derive `amount` from `order.total_amount` (Req 3, never from client input).
2. Create `payment_transactions` row (`status = INITIATED`, `provider`, `phone_number`, `amount`).
3. Call `adapter.initiate(order, phoneNumber)`, store returned `checkout_request_id`/`reference_id`.
4. On adapter error (network failure to MNO), set `payment_transactions.status = FAILED` and return a client-facing error distinct from a signature/callback failure.

## Callback Flow (Req 5–10)

1. Look up the adapter for `:provider` in the URL.
2. `adapter.verifyCallback(rawRequest)` — reject 401 immediately on failure, write nothing (Req 6).
3. `adapter.parseCallback(rawRequest)` → normalized `{referenceId, checkoutRequestId, status, raw}`.
4. Look up the matching `payment_transactions` row by `reference_id`/`checkout_request_id`.
5. **Idempotency check (Req 9):** if that row's `status` is already `SUCCESSFUL` or `FAILED` (i.e. already processed), store the raw payload again for audit but skip re-applying the status cascade — return 200 to satisfy the MNO's retry expectation without double-processing.
6. Otherwise, update `payment_transactions.status` and `response_payload` (Req 7–8, 10); if `SUCCESSFUL`, update `orders.status = PAID` using the same status-transition-table mechanism as [[../orders/design]] (not a separate ad hoc write).

## Status Polling (Req 11)

`GET /payments/:orderId/status` returns the most recent `payment_transactions` row for that order (ordered by `created_at DESC LIMIT 1`) — supports the mobile app's retry model in [[../mobile-app/design]] where a new row is created per attempt (Req 4).

## Per-Provider Notes (fill in once each MNO's sandbox docs are reviewed — flagged as open items, not yet resolved)

- **M-Pesa (Vodacom)**: verification mechanism TBD from sandbox docs — implement first per `PLAN.md` M7/M8 as the reference adapter.
- **Mixx by Yas (Tigo Pesa)**: verification mechanism TBD.
- **Airtel Money**: verification mechanism TBD.

Each adapter's actual signature scheme, payload shape, and any IP-allowlisting requirement gets documented in this file once implemented — do not assume they're identical.
