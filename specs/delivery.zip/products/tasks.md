# Products — Tasks

- [ ] Implement `GET /products` with pagination, `search`, `category_id` filters, availability flag. (Req 1–4)
- [ ] Implement `POST /products` (admin), reject `price < 0` at DTO validation. (Req 5, 11)
- [ ] Implement `PATCH /products/:id` (admin), incl. `is_available` toggle. (Req 6–7)
- [ ] Implement `GET /products/low-stock` (admin). (Req 8)
- [ ] Build shared `UploadService` (S3) in `/backend/src/uploads`; implement `POST /products/:id/image`. (Req 9)
- [ ] Wire `/backend/src/categories` to reuse `UploadService` for `icon_url`. (supports [[../categories/design]])
- [ ] Apply `RolesGuard` to all write endpoints; test `CUSTOMER` token gets 403. (Req 10)
- [ ] Write test: out-of-stock product still appears in listing with correct in-stock flag. (Req 4)
- [ ] Update `/docs` OpenAPI, flagging the 4 admin endpoints as additions beyond the spec PDF's list.
