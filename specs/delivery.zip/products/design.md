# Products — Design

Implements [[requirements]]. Built alongside [[../categories/design]] per `PLAN.md` Phase 4.

## Endpoints

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/api/v1/products` | Public | Req 1–4, the one endpoint explicitly in the spec PDF's list |
| POST | `/api/v1/products` | Admin | Req 5 |
| PATCH | `/api/v1/products/:id` | Admin | Req 6–7 |
| GET | `/api/v1/products/low-stock` | Admin | Req 8 |
| POST | `/api/v1/products/:id/image` | Admin | Req 9, multipart upload |
| GET | `/api/v1/products/admin` | Admin | Not in Req 1's field list — addition beyond the spec PDF, needed by [[../admin-web/requirements]] Req 4: the public listing filters `is_available = true`, so the admin management view needs an unfiltered, paginated equivalent (same `search`/`category_id` params) to see and re-activate deactivated products. Response includes `is_available` (added to the shared product mapper, previously omitted). |
| GET | `/api/v1/products/:id` | Admin | Not in the spec PDF — needed by [[../admin-web/requirements]] Req 4's edit view to fetch a single product (incl. deactivated) by id. Declared after the `admin`/`low-stock` literal routes so it doesn't shadow them. |

## Data Model

Uses `products` table as-is from [[../database/design]]. `stock_quantity` is only ever decremented by the orders module's stock-lock transaction ([[../orders/design]]) — this module's `PATCH` endpoint can adjust it directly for manual restocking, but must not bypass the same optimistic-visibility concerns (i.e. a manual stock edit while an order is mid-checkout should still be safe since the orders module takes a row lock regardless of who else is writing to the row).

## Pagination & Search

- `GET /products` accepts `page`, `pageSize` (default 20, max 100), `search`, `category_id` query params.
- Search uses a simple `ILIKE '%term%'` against `name` for MVP — full-text search (e.g. Postgres `tsvector`) is a post-MVP enhancement if search quality becomes an issue.
- Response includes pagination metadata (`total`, `page`, `pageSize`) so clients can render pagination controls.

## Image Upload

- `POST /products/:id/image` accepts multipart/form-data, validates file type (jpg/png/webp) and size (max 5MB), uploads to S3 under a key like `products/{product_id}/{uuid}.{ext}`, then updates `products.image_url` to the resulting public (or signed, if bucket is private) URL.
- Categories reuse this same upload path for `icon_url` (see [[../categories/design]]) rather than a duplicate implementation — one shared `UploadService` in `/backend/src/common` or a dedicated `/backend/src/uploads` module.

## Low-Stock Alerts

- `GET /products/low-stock` is a pull-based query for MVP (admin dashboard polls or checks on load) — no push notification to admins in MVP scope; a scheduled digest/notification is a post-MVP enhancement.
