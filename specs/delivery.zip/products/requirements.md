# Products — Requirements

Source: `grocery_app_specifications.pdf` §3A ("Real-time product search, filtering, and stock availability verification"), §3C ("Stock entry, price updates ... low-stock alerts"), §4 (`GET /api/v1/products`). Admin CRUD and image upload are additions beyond the spec's 7-endpoint list, required by the admin dashboard (§3C).

## User Story: As a customer, I want to browse and search products so I can build my cart.

1. WHEN a client calls `GET /api/v1/products`, THE SYSTEM SHALL return a paginated list of products where `is_available = true`, each including `id`, `name`, `price`, `unit`, `stock_quantity`, `image_url`, `category_id`.
2. WHEN `GET /api/v1/products` includes a `search` query param, THE SYSTEM SHALL filter results by case-insensitive match against `name`.
3. WHEN `GET /api/v1/products` includes a `category_id` query param, THE SYSTEM SHALL filter results to that category.
4. WHEN a product's `stock_quantity = 0`, THE SYSTEM SHALL still return it in listings (so it remains visible) but the client-facing "in stock" flag SHALL be false — the client app is responsible for disabling add-to-cart on out-of-stock items using this flag.

## User Story: As an admin, I want to manage product inventory.

5. WHEN an authenticated `ADMIN` calls `POST /api/v1/products` with valid fields (`name`, `price >= 0`, `unit`, `category_id`, `stock_quantity`), THE SYSTEM SHALL create the product.
6. WHEN an authenticated `ADMIN` calls `PATCH /api/v1/products/:id` with updated fields (including price or stock changes), THE SYSTEM SHALL update the product.
7. WHEN an authenticated `ADMIN` calls `PATCH /api/v1/products/:id` to set `is_available = false`, THE SYSTEM SHALL hide it from public listings without deleting it.
8. WHEN an authenticated `ADMIN` calls `GET /api/v1/products/low-stock?threshold=N`, THE SYSTEM SHALL return all available products where `stock_quantity <= N` (default threshold: 10).
9. WHEN an authenticated `ADMIN` uploads an image via `POST /api/v1/products/:id/image`, THE SYSTEM SHALL store it in the S3 bucket configured per [[../constitution]] and set `products.image_url` to the resulting object URL.
10. IF a non-`ADMIN` calls any product write endpoint (`POST`, `PATCH`, image upload), THEN THE SYSTEM SHALL reject with 403 Forbidden.
11. IF a `POST` or `PATCH` request supplies `price < 0`, THEN THE SYSTEM SHALL reject with 400 before the database CHECK constraint would even be hit.
