# Categories — Design

Implements [[requirements]]. Built alongside [[../products/design]] per `PLAN.md` Phase 4 (same phase, same CRUD patterns established together).

## Endpoints

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/api/v1/categories` | Public | Req 1, only `is_active = true` |
| POST | `/api/v1/categories` | Admin | Req 2 |
| PATCH | `/api/v1/categories/:id` | Admin | Req 3–4 |
| POST | `/api/v1/categories/:id/icon` | Admin | Not in Req 2's field list — addition beyond the spec PDF, per ISSUE-014 (real upload endpoint, not manual URL paste). Multipart upload via the same shared `UploadService` as `POST /products/:id/image` |
| GET | `/api/v1/categories/admin` | Admin | Not in Req 1's field list — addition beyond the spec PDF, needed by [[../admin-web/requirements]] Req 3: the public listing filters `is_active = true`, so the admin management view needs an unfiltered equivalent to see and re-activate deactivated categories. |

No hard-delete endpoint — soft delete via `is_active = false` is the only removal path (Req 4), matching the `ON DELETE SET NULL` behavior on `products.category_id` being reserved for a hard delete this module never triggers.

## Data Model

Uses `categories` table as-is from [[../database/design]]. No schema changes.

## Notes

- Category list is small and rarely changes — no pagination needed on `GET /categories` (unlike `GET /products`).
- Icon upload reuses the same image-upload endpoint as products (see [[../products/design]]) rather than a separate upload path.
