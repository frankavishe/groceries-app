# Categories — Requirements

Source: `grocery_app_specifications.pdf` §3C ("Inventory Control: ... category creation"). Public read is implied by the customer app needing to filter by category (§3A "filtering").

## User Story: As a customer, I want to browse categories so I can filter the product catalog.

1. WHEN a client calls `GET /api/v1/categories`, THE SYSTEM SHALL return all categories where `is_active = true`, each with `id`, `name`, `icon_url`.

## User Story: As an admin, I want to manage categories so the catalog stays organized.

2. WHEN an authenticated `ADMIN` calls `POST /api/v1/categories` with a `name` (and optional `icon_url`), THE SYSTEM SHALL create a new category defaulting `is_active = true`.
3. WHEN an authenticated `ADMIN` calls `PATCH /api/v1/categories/:id` with updated fields, THE SYSTEM SHALL update that category.
4. WHEN an authenticated `ADMIN` calls `PATCH /api/v1/categories/:id` to set `is_active = false`, THE SYSTEM SHALL soft-delete the category (it stops appearing in `GET /categories` and in product filters) without deleting products that reference it — per [[../database/requirements]] Req 8, referencing products get `category_id = NULL` only on hard delete, which this module does not expose.
5. IF a non-`ADMIN` calls `POST`, `PATCH`, or `DELETE` on `/api/v1/categories`, THEN THE SYSTEM SHALL reject with 403 Forbidden.
