# Categories — Tasks

- [ ] Implement `GET /categories` (public, filters `is_active = true`). (Req 1)
- [ ] Implement `POST /categories` (admin). (Req 2)
- [ ] Implement `PATCH /categories/:id` incl. soft-delete via `is_active`. (Req 3–4)
- [ ] Apply `RolesGuard` to write endpoints; test `CUSTOMER` token gets 403. (Req 5)
- [ ] Confirm deactivating a category doesn't null out `products.category_id` for its products (only hard delete does, per [[../database/requirements]] Req 8). (Req 4)
- [ ] Update `/docs` OpenAPI.
