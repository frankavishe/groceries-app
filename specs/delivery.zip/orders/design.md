# Orders — Design

Implements [[requirements]]. This is the module [[../constitution]]'s stock-lock invariant exists to constrain — read that section before changing anything here.

## Endpoints

| Method | Path | Access | Notes |
|---|---|---|---|
| POST | `/api/v1/orders` | Customer | Req 1–4 |
| GET | `/api/v1/orders` | Customer (own only) / Admin (all) | Req 6. Accepts an optional `status` filter (not in the spec PDF — added for [[../admin-web/requirements]] Req 6's status-filterable list view). |
| GET | `/api/v1/orders/:id` | Customer (own only) / Admin | Req 7 |
| PATCH | `/api/v1/orders/:id/status` | Admin | Req 8–10 |

## Stock-Lock Transaction (Req 1–3)

```
BEGIN;
  -- lock rows in ascending product_id order to avoid cross-order deadlocks
  SELECT id, stock_quantity FROM products
    WHERE id IN (:productIds) ORDER BY id ASC FOR UPDATE;

  -- application-level check against each requested quantity
  -- if any item's requested quantity > locked stock_quantity: ROLLBACK, return 409 with failing item(s)

  UPDATE products SET stock_quantity = stock_quantity - :qty WHERE id = :productId;  -- per item
  INSERT INTO orders (...) VALUES (..., status='PENDING');
  INSERT INTO order_items (...) VALUES (...);  -- per item
COMMIT;
```
- Product IDs are sorted before the `FOR UPDATE` query specifically to give concurrent multi-item orders a consistent lock-acquisition order — prevents the classic deadlock where order A locks {1,2} while order B locks {2,1}.
- `total_amount` computed server-side from current `products.price` at order time (never trust a client-supplied price) plus `delivery_fee` (flat fee per [[../constitution]] pending a real delivery-fee policy decision).

## Reservation Timeout (Req 5)

A scheduled job (NestJS `@Cron`, e.g. every 5 minutes) queries `orders WHERE status = 'PENDING' AND created_at < NOW() - INTERVAL '20 minutes'`, and for each: sets `status = CANCELLED`, restores `stock_quantity` for its `order_items` in a transaction (same locking pattern as above, in reverse). This is the same code path used for Req 10's cancellation-triggered stock restoration — implement as one shared `releaseReservedStock(orderId)` method called from both the cron job and the `PATCH .../status` handler.

## Status State Machine (Req 8–10)

Valid forward transitions: `PENDING → PAID → PROCESSING → DISPATCHED → DELIVERED`. `CANCELLED` reachable from any state except `DELIVERED`. Implement as an explicit transition table (map of `currentStatus → Set<allowedNextStatus>`) checked before any status write — not ad hoc if/else chains, since this table needs to be referenced identically by both this endpoint and the future payment-callback handler ([[../payments/design]]) that also moves `orders.status` (e.g. PAID on successful payment).

## Data Model

Uses `orders`, `order_items`, `products` from [[../database/design]]. No schema changes needed for MVP order/stock-lock logic. The `assigned_agent_id` addition tracked in [[../database/design]]'s "Pending Schema Additions" is consumed by [[../delivery/design]], not this module directly (though this module's status transitions interact with delivery's `DISPATCHED`/`DELIVERED` states).

## Concurrency Test (verifies Req 3)

A load test script issues N parallel `POST /orders` requests for the same product with stock deliberately set below N — assert that exactly `stock_quantity` orders succeed and the rest get 409, and that final `stock_quantity` is exactly 0 (never negative, never left over from a lost update).
