# Orders — Requirements

Source: `grocery_app_specifications.pdf` §3B ("Automated lock on product stock during checkout to prevent double-allocation"), §4 (`POST /api/v1/orders`, `PATCH /api/v1/orders/:id/status`). This is the highest-risk module per [[../constitution]]'s stock-lock invariant.

## User Story: As a customer, I want to place an order so my cart's items get reserved and I can proceed to payment.

1. WHEN an authenticated `CUSTOMER` calls `POST /api/v1/orders` with a list of `{product_id, quantity}` items, THE SYSTEM SHALL, in a single transaction, verify sufficient stock for every item, decrement `stock_quantity` accordingly, create the `order` (`status = PENDING`) and its `order_items`, and return the created order.
2. IF any requested item's `quantity` exceeds its current `stock_quantity` at lock time, THEN THE SYSTEM SHALL reject the entire order with 409 Conflict, roll back all changes (no partial stock decrement), and identify which item(s) failed.
3. WHEN two or more customers concurrently attempt to order the last unit(s) of the same product, THE SYSTEM SHALL guarantee at most one of them succeeds in reserving that unit — never both (per [[../constitution]] stock-lock invariant).
4. THE SYSTEM SHALL compute `orders.total_amount` as the sum of `order_items.subtotal` plus `delivery_fee`.
5. WHEN a `PENDING` order's payment has not completed within 20 minutes of creation, THE SYSTEM SHALL cancel the order (`status = CANCELLED`) and restore its reserved stock to the affected products.

## User Story: As a customer, I want to view my orders so I can track their status.

6. WHEN an authenticated `CUSTOMER` calls `GET /api/v1/orders`, THE SYSTEM SHALL return only that customer's own orders, paginated, most recent first.
7. WHEN an authenticated `CUSTOMER` calls `GET /api/v1/orders/:id` for an order they don't own, THE SYSTEM SHALL reject with 403 or 404 (not leak existence of another customer's order — decide 403 vs 404 here: recommend 404, to avoid confirming order-ID existence to non-owners).

## User Story: As an admin, I want to update order status so the fulfillment pipeline reflects reality.

8. WHEN an authenticated `ADMIN` calls `PATCH /api/v1/orders/:id/status` with a new valid `order_status`, THE SYSTEM SHALL update the order's status.
9. THE SYSTEM SHALL enforce that status transitions only move forward through `PENDING → PAID → PROCESSING → DISPATCHED → DELIVERED`, or to `CANCELLED` from any non-`DELIVERED` state — a transition to an earlier state (e.g. `DELIVERED → PROCESSING`) SHALL be rejected with 400.
10. WHEN an order's `status` transitions to `CANCELLED` from a state that had reserved stock (`PENDING` or `PAID`), THE SYSTEM SHALL restore the reserved stock to the affected products (same mechanism as Req 5).
