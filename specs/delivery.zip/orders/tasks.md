# Orders — Tasks

- [ ] Implement the stock-lock transaction (`SELECT ... FOR UPDATE`, sorted product IDs, re-check, decrement, insert order + items). (Req 1–4)
- [ ] Implement `releaseReservedStock(orderId)` shared method (restores stock, sets `status = CANCELLED`). (Req 5, 10)
- [ ] Implement the 20-minute PENDING-order expiry cron job calling `releaseReservedStock`. (Req 5)
- [ ] Implement `GET /orders` (own-only for customer, all for admin), paginated. (Req 6)
- [ ] Implement `GET /orders/:id` with ownership check (404 for non-owners). (Req 7)
- [ ] Implement the order-status transition table + `PATCH /orders/:id/status`, calling `releaseReservedStock` on any cancellation. (Req 8–10)
- [ ] Write the concurrency test described in [[design]] and confirm no overselling under parallel load. (Req 3, `PLAN.md` M4 verification)
- [ ] Write test: invalid backward status transition rejected with 400. (Req 9)
- [ ] Update `/docs` OpenAPI.
