# Mobile App — Requirements

Source: `grocery_app_specifications.pdf` §3A (Product Catalog, Cart Management, Mobile Payments). Flutter, Android only, per [[../constitution]]. Consumes backend specs ([[../products/requirements]], [[../orders/requirements]], [[../payments/requirements]], [[../auth/requirements]]) rather than redefining their contracts.

## User Story: As a customer, I want to register/log in from the app.

1. THE SYSTEM SHALL provide registration and OTP-verification screens backed by [[../auth/requirements]] Req 1–4.
2. THE SYSTEM SHALL provide a login screen backed by [[../auth/requirements]] Req 6–7, persisting the JWT securely on-device (e.g. Flutter secure storage, not plain SharedPreferences) between sessions.

## User Story: As a customer, I want to browse and search products.

3. THE SYSTEM SHALL display the product catalog from [[../products/requirements]] Req 1, with category filter chips from [[../categories/requirements]] Req 1.
4. WHEN the user types in the search field, THE SYSTEM SHALL query `GET /products?search=...` and update results live (debounced, not on every keystroke).
5. WHEN a product's in-stock flag is false, THE SYSTEM SHALL visually indicate it (e.g. "Out of stock" badge) and disable its add-to-cart control.

## User Story: As a customer, I want to manage a cart that survives app restarts and offline periods.

6. WHEN the user adds/removes/adjusts items in the cart, THE SYSTEM SHALL persist the cart to on-device storage (Hive) so it survives app restart.
7. WHEN the app has no network connectivity, THE SYSTEM SHALL still allow browsing previously-loaded products and full cart manipulation; only checkout/payment requires connectivity.
8. WHEN the app regains connectivity after an offline period, THE SYSTEM SHALL NOT silently re-validate stock levels against the persisted cart without user awareness — the checkout step (Req 9) SHALL always re-verify current stock/price server-side before charging, since the cart is a local-only draft.

## User Story: As a customer, I want to check out and pay via mobile money.

9. WHEN the user taps checkout, THE SYSTEM SHALL call `POST /api/v1/orders` (per [[../orders/requirements]] Req 1) with the current cart contents and handle the 409 insufficient-stock response by showing which item(s) are no longer available.
10. WHEN an order is created successfully, THE SYSTEM SHALL prompt the user to select a mobile money provider (M-Pesa, Mixx by Yas, Airtel Money) and initiate payment via [[../payments/requirements]].
11. WHEN payment is initiated, THE SYSTEM SHALL poll the payment status endpoint at a regular interval (e.g. every 3 seconds, up to a timeout) and show a waiting/spinner state until `SUCCESSFUL`, `FAILED`, or timeout.
12. WHEN payment succeeds, THE SYSTEM SHALL clear the cart and show an order-confirmation screen; when it fails or times out, THE SYSTEM SHALL let the user retry payment for the same (still-`PENDING`) order without re-reserving stock a second time.

## User Story: As a customer, I want to see my order history and status.

13. THE SYSTEM SHALL provide an order-history screen backed by [[../orders/requirements]] Req 6, and an order-detail screen showing current status.
