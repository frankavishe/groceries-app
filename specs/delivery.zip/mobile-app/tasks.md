# Mobile App — Tasks

- [ ] Scaffold Flutter project in `/mobile-app`; pick and wire state management (bloc or Riverpod). (supports all)
- [ ] Build Register/OTP/Login screens against [[../auth/design]]. (Req 1–2)
- [ ] Implement secure JWT storage (`flutter_secure_storage`). (Req 2)
- [ ] Build Catalog screen: search (debounced), category filter, in-stock indicator. (Req 3–5)
- [ ] Implement Hive-backed cart (add/remove/adjust, survives restart). (Req 6)
- [ ] Implement offline browsing (cached catalog) + offline cart manipulation + checkout-disabled-when-offline. (Req 7–8)
- [ ] Implement checkout flow: `POST /orders`, handle 409 insufficient-stock gracefully. (Req 9)
- [ ] Implement payment-provider selection + `POST /payments/initiate` call (stub endpoint initially, per [[design]]). (Req 10)
- [ ] Implement payment-status polling with timeout handling. (Req 11)
- [ ] Implement success/failure/retry flow, cart clear on success. (Req 12)
- [ ] Build Order History / Order Detail screens. (Req 13)
- [ ] Manual walkthrough on Android emulator/device per `PLAN.md` M6 verification: browse → cart → kill/restart app → checkout with stub payment → confirm order in admin dashboard.
- [ ] Swap stub payment for real [[../payments/design]] integration once that module lands; remove the build-flag-gated stub path from release builds.
