# Mobile App — Design

Implements [[requirements]]. Flutter app in `/mobile-app`, Android only.

## State Management & Persistence

- `flutter_bloc` or Riverpod (pick one before Phase 7 of `PLAN.md` and record the choice here) for app state.
- Cart state persisted via Hive (a local `CartBox` storing `{productId, quantity, priceSnapshot}` entries) — survives app kill/restart (Req 6). Price/stock shown from the local snapshot is always re-verified server-side at checkout (Req 8), never trusted for the actual charge.
- JWT persisted via `flutter_secure_storage`, not Hive/SharedPreferences, since it's a credential (Req 2).

## Screens

- `RegisterScreen` → `OtpVerifyScreen` → `LoginScreen` (Req 1–2)
- `CatalogScreen` (search bar, category filter chips, product grid) (Req 3–5)
- `CartScreen` (Req 6–8)
- `CheckoutScreen` → `PaymentProviderSelectScreen` → `PaymentPendingScreen` (polling spinner) → `OrderConfirmationScreen` (Req 9–12)
- `OrderHistoryScreen` / `OrderDetailScreen` (Req 13)

## Payments UX (Req 9–12)

- Checkout is a two-step network flow: (1) `POST /orders` creates a `PENDING` order and returns its `id`; (2) `POST /payments/initiate` with that `order_id` + chosen provider + phone number triggers the USSD push.
- Client polls `GET /payments/:orderId/status` (endpoint defined in [[../payments/design]]) every 3s for up to 2 minutes; on timeout, show "still processing, check Order History later" rather than treating it as failure — an MNO callback can arrive after the client gives up.
- Retry (Req 12): re-calling `payments/initiate` for the same still-`PENDING` order must be idempotent on the backend side (new `checkout_request_id`, same `order_id`) — this app never calls `POST /orders` twice for one checkout attempt.

## Offline Handling (Req 7–8)

- Product catalog is cached locally (last successful fetch) so browsing works offline; a connectivity banner indicates stale/offline data.
- Cart manipulation works fully offline since it's local-only until checkout.
- Checkout button is disabled with an explanatory message when offline (network required to call `POST /orders`).

## Stub Payment for Early Development

Per `PLAN.md` Phase 7, before the real payments engine ([[../payments/design]]) exists, `PaymentProviderSelectScreen` can call a stub backend endpoint that immediately marks the order `PAID` — gated behind a build flag so it's never reachable in a release build once real payments land.
