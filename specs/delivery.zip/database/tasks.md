# Database — Tasks

Each task cites the [[requirements]] it satisfies.

- [ ] Choose ORM (TypeORM or Prisma); confirm it supports raw `SELECT ... FOR UPDATE` row locking. (Req 15, [[constitution]] stock-lock invariant)
- [ ] Write migration: enums `user_role`, `order_status`, `payment_provider`, `payment_status`. (Req 1–4)
- [ ] Write migration: `users` table with unique `phone_number`, unique nullable `email`, default `role = CUSTOMER`. (Req 5–7, 17)
- [ ] Write migration: `categories` table. (supports Req 8)
- [ ] Write migration: `products` table with `category_id ON DELETE SET NULL`, `price CHECK (price >= 0)`. (Req 8–9)
- [ ] Write migration: `orders` table with `user_id ON DELETE SET NULL`. (Req 10)
- [ ] Write migration: `order_items` table with `order_id ON DELETE CASCADE`, `quantity CHECK (quantity > 0)`. (Req 11–12)
- [ ] Write migration: `payment_transactions` table with `order_id ON DELETE RESTRICT`, unique `reference_id`, unique `checkout_request_id`. (Req 13–14)
- [ ] Write migration: indexes `idx_products_category`, `idx_orders_user`, `idx_payments_order`, `idx_payments_reference`. (Req 15)
- [ ] Verify all migrations run cleanly up and down against a fresh local Postgres (via `docker-compose`). (all)
- [ ] Write seed script per [[design]] (admin user, categories, products incl. zero-stock and low-stock cases); confirm idempotent re-run. (supports M3/M4 verification in `PLAN.md`)
- [ ] Document final ORM choice and any deviation from the DDL in [[design]].
