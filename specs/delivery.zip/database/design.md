# Database — Design

Implements requirements in [[requirements]]. See [[constitution]] for the stock-lock and idempotency invariants this schema exists to support.

## Migration Strategy

Schema is implemented as versioned migrations under `/backend/src/database/migrations`, applied via TypeORM's migration runner (see ISSUE-001 in `/issues.md` for the decision rationale: native QueryBuilder `.setLock('pessimistic_write')` support for the stock-lock invariant, built-in migration CLI). Migrations are written directly from the DDL in `grocery_app_specifications.pdf` §2, in this order (later tables reference earlier ones via FK):

1. Enums: `user_role`, `order_status`, `payment_provider`, `payment_status`
2. `users`
3. `categories`
4. `products` (FK → `categories`)
5. `orders` (FK → `users`)
6. `order_items` (FK → `orders`, `products`)
7. `payment_transactions` (FK → `orders`)
8. Indexes: `idx_products_category`, `idx_orders_user`, `idx_payments_order`, `idx_payments_reference`

No table or column is added beyond the PDF's schema without a corresponding note in this file explaining why (e.g. an `assigned_agent_id` column on `orders` will be needed once `specs/delivery/design.md` is written — flagged here as a **pending schema addition**, not yet migrated).

## Pending Schema Additions (tracked, not yet implemented)

- `orders.assigned_agent_id UUID REFERENCES users(id)` — needed for the delivery-agent view (`specs/delivery`). Add as its own migration when that module starts, not bundled into the base schema, so the base schema stays a faithful match to the original spec PDF.
- `products.image_url` already exists as a plain URL column per spec; the actual upload mechanism (`specs/products/design.md`) writes to this column after uploading to S3 — no schema change needed for that.

## Seed Data

A seed script (`/backend/src/database/seed.ts` or equivalent) creates, for local/dev use only:
- One `ADMIN` user with a known test phone number/password.
- 3–5 `categories`.
- 10–15 `products` spread across those categories, with varied `stock_quantity` (including at least one product with `stock_quantity = 0` and one with a low quantity, e.g. 2, to exercise low-stock alerts).

Seed script must be idempotent (safe to re-run against an already-seeded DB — upsert or check-before-insert).

## Concurrency Note

`SELECT ... FOR UPDATE` (used by the orders module per [[constitution]]) is implemented via TypeORM QueryBuilder's `.setLock('pessimistic_write')`, applied to `products` rows in ascending `product_id` order within a single transaction.
