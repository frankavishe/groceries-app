# Database — Requirements

Source: `grocery_app_specifications.pdf` §2 (schema is fully specified there; this file restates it as testable acceptance criteria). See [[constitution]] for invariants this schema must support.

## User Story: As the system, I need a relational schema that enforces data integrity so application code doesn't have to.

1. THE SYSTEM SHALL define enum type `user_role` with values `CUSTOMER`, `ADMIN`, `DELIVERY_AGENT`.
2. THE SYSTEM SHALL define enum type `order_status` with values `PENDING`, `PAID`, `PROCESSING`, `DISPATCHED`, `DELIVERED`, `CANCELLED`.
3. THE SYSTEM SHALL define enum type `payment_provider` with values `MPESA`, `MIXX_BY_YAS`, `AIRTEL_MONEY`.
4. THE SYSTEM SHALL define enum type `payment_status` with values `INITIATED`, `PENDING`, `SUCCESSFUL`, `FAILED`.
5. WHEN a user record is created, THE SYSTEM SHALL require a unique, non-null `phone_number` and reject duplicates.
6. WHEN a user record includes an `email`, THE SYSTEM SHALL require it be unique if present (nullable otherwise).
7. THE SYSTEM SHALL default a new user's `role` to `CUSTOMER` unless explicitly set otherwise.
8. WHEN a category referenced by a product is deleted, THE SYSTEM SHALL set that product's `category_id` to NULL rather than blocking the delete or cascading the delete to products.
9. THE SYSTEM SHALL reject any product `price` less than 0 at the database level (CHECK constraint), independent of any application-level validation.
10. WHEN a user referenced by an order is deleted, THE SYSTEM SHALL set that order's `user_id` to NULL rather than deleting the order.
11. WHEN an order is deleted, THE SYSTEM SHALL cascade-delete its `order_items`.
12. THE SYSTEM SHALL reject any `order_items.quantity` less than or equal to 0 at the database level.
13. THE SYSTEM SHALL prevent deletion of an order that has any associated `payment_transactions` row (ON DELETE RESTRICT).
14. THE SYSTEM SHALL enforce uniqueness on `payment_transactions.reference_id` and `payment_transactions.checkout_request_id` independently, to support the idempotency invariant in [[constitution]].
15. THE SYSTEM SHALL provide indexes on `products.category_id`, `orders.user_id`, `payment_transactions.order_id`, and `payment_transactions.reference_id` to keep the lookup patterns used by the orders/products/payments modules performant as data grows.
16. THE SYSTEM SHALL stamp `created_at`/`updated_at` (where present) with `CURRENT_TIMESTAMP` on insert.
