# Users — Design

Implements [[requirements]]. Depends on [[../auth/design]] for `JwtStrategy`/`RolesGuard`.

## Endpoints

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/api/v1/users/me` | Any authenticated | Req 1 |
| PATCH | `/api/v1/users/me` | Any authenticated | Req 2–3 |
| GET | `/api/v1/users` | Admin | Req 4, paginated same pattern as `GET /products` |
| PATCH | `/api/v1/users/:id/role` | Admin | Req 5 |
| PATCH | `/api/v1/users/:id/status` | Admin | Req 6 |

## Data Model

Uses `users` table as-is from [[../database/design]] — no schema changes needed; this module is pure CRUD over existing columns plus role/status transitions restricted to admin.

## Notes

- `PATCH /users/me` uses a DTO that only exposes `full_name`/`email` fields — the DTO shape itself prevents `role`/`phone_number` injection (whitelist validation), which resolves Req 3's open question: reject at the validation layer with 400 if extra fields are present (`forbidNonWhitelisted` in NestJS's `ValidationPipe`).
- Deactivating a user (`is_active = false`) does not delete or anonymize their data — orders/payments FKs (`ON DELETE SET NULL`) only matter on hard delete, which this module does not expose. No user hard-delete endpoint exists in MVP scope.
