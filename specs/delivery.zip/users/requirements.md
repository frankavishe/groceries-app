# Users — Requirements

Covers profile management and role administration, distinct from the authentication mechanics in [[../auth/requirements]]. Not explicitly listed in the spec PDF's 7-endpoint list — an addition needed for the admin dashboard and for customers managing their own profile.

## User Story: As a customer, I want to view and update my own profile.

1. WHEN an authenticated `CUSTOMER` calls `GET /api/v1/users/me`, THE SYSTEM SHALL return their own `id`, `full_name`, `phone_number`, `email`, `role`, `created_at`.
2. WHEN an authenticated `CUSTOMER` calls `PATCH /api/v1/users/me` with a new `full_name` and/or `email`, THE SYSTEM SHALL update only those fields and SHALL NOT allow the request to change `phone_number` or `role`.
3. IF a `PATCH /api/v1/users/me` request includes `role` or `phone_number`, THEN THE SYSTEM SHALL ignore those fields silently or reject the request — decide and record the choice here before implementation (recommend: reject with 400, to surface client bugs rather than silently drop data).

## User Story: As an admin, I want to manage user accounts and roles.

4. WHEN an authenticated `ADMIN` calls `GET /api/v1/users` (paginated), THE SYSTEM SHALL return a list of all users with their roles and `is_active` status.
5. WHEN an authenticated `ADMIN` calls `PATCH /api/v1/users/:id/role` with a new valid `user_role` value, THE SYSTEM SHALL update that user's role.
6. WHEN an authenticated `ADMIN` calls `PATCH /api/v1/users/:id/status` to set `is_active = false`, THE SYSTEM SHALL deactivate the account; a deactivated user SHALL NOT be able to log in ([[../auth/requirements]] Req 7).
7. IF a non-`ADMIN` calls any `/api/v1/users` endpoint other than `/me`, THEN THE SYSTEM SHALL reject with 403 Forbidden.
