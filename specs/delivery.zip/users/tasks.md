# Users — Tasks

- [ ] Implement `GET /users/me` / `PATCH /users/me` with whitelist-validated DTO (rejects `role`/`phone_number`). (Req 1–3)
- [ ] Implement `GET /users` (admin, paginated). (Req 4)
- [ ] Implement `PATCH /users/:id/role` (admin). (Req 5)
- [ ] Implement `PATCH /users/:id/status` (admin); confirm deactivated users are rejected at login per [[../auth/requirements]] Req 7. (Req 6)
- [ ] Apply `RolesGuard` to all admin-only routes; test a `CUSTOMER` token gets 403. (Req 7)
- [ ] Update `/docs` OpenAPI with these 5 endpoints, noting they're additions beyond the spec PDF's original list.
