# Auth — Design

Implements [[requirements]]. See [[constitution]] for the `OtpSenderPort` adapter rule and RBAC invariant.

## Endpoints

| Method | Path | Access | Notes |
|---|---|---|---|
| POST | `/api/v1/auth/register` | Public | Req 1–3 |
| POST | `/api/v1/auth/verify-otp` | Public | not in original 7-endpoint list; needed for Req 4–5 — flagged as an addition beyond the spec PDF |
| POST | `/api/v1/auth/login` | Public | Req 6–9 |

## Data Model

Uses `users` table as defined in [[../database/design]]. No new columns needed for registration/login; OTP codes and their expiry/attempt-count are ephemeral and belong in Redis (already provisioned per [[constitution]]), keyed by `phone_number`, not persisted to Postgres — avoids schema churn for a short-lived value and reuses the cache layer that's already in the architecture.

## OTP Flow

1. `register` creates the `users` row (unverified — add an `is_verified BOOLEAN DEFAULT FALSE` application-level flag; if this requires a schema change, record it in `specs/database/design.md`'s "Pending Schema Additions").
2. Generate a 6-digit OTP, store in Redis with a 5-minute TTL and an attempt counter, key `otp:{phone_number}`.
3. Send via `OtpSenderPort.send(phone_number, code)` — concrete implementation calls Africa's Talking's SMS API; local/dev implementation logs to console.
4. `verify-otp` checks the submitted code against Redis; on match, sets `is_verified = true` and deletes the Redis key; on mismatch, increments the attempt counter (Req 5) and returns 400.

## JWT

- Signed with a server-side secret (from `/backend/src/config`, per [[constitution]]'s config module).
- Payload: `{ sub: user.id, role: user.role, phone_number }`.
- `RolesGuard` (in `/backend/src/common`) reads `role` from the verified JWT and compares against an endpoint's `@Roles(...)` decorator metadata — this guard is shared by every other module's protected routes (products admin CRUD, orders, payments, delivery).

## Error Handling

- Duplicate phone on register → 409 with a machine-readable error code (`PHONE_ALREADY_REGISTERED`), not just a message, so mobile/admin clients can branch on it.
- Wrong OTP → 400 `INVALID_OTP`; OTP expired → 400 `OTP_EXPIRED`; too many attempts → 429 `OTP_ATTEMPTS_EXCEEDED`.
- Invalid login → 401 generic (`INVALID_CREDENTIALS`) — deliberately do not distinguish "wrong password" from "user not found" in the response, to avoid user enumeration.
