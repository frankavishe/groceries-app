# Auth — Requirements

Source: `grocery_app_specifications.pdf` §3B ("Auth Module: Phone-based OTP / JWT authentication with role-based access control") and §4 (`POST /auth/register`, `POST /auth/login`). See [[constitution]] for the OTP provider decision (Africa's Talking) and RBAC rule.

## User Story: As a customer, I want to register with my phone number so I can start shopping.

1. WHEN a client calls `POST /api/v1/auth/register` with a valid `full_name`, `phone_number`, and `password`, THE SYSTEM SHALL create a new user with `role = CUSTOMER` and return a success response.
2. IF `phone_number` is already registered, THEN `POST /api/v1/auth/register` SHALL reject the request with a 409 Conflict and no new user is created.
3. WHEN registration succeeds, THE SYSTEM SHALL send an OTP to the given `phone_number` via Africa's Talking (or the console/log sender in local dev, per [[constitution]]).
4. WHEN a client submits the correct OTP for a pending registration, THE SYSTEM SHALL mark the account verified and allow login; an unverified account SHALL NOT be able to log in.
5. IF an incorrect OTP is submitted more than 5 times for the same registration attempt, THEN THE SYSTEM SHALL invalidate that OTP and require a new one to be requested.

## User Story: As any user, I want to log in with my phone number so I can access my account.

6. WHEN a client calls `POST /api/v1/auth/login` with a correct `phone_number`/credential pair for a verified, active user, THE SYSTEM SHALL return a JWT access token.
7. IF the credentials are invalid OR the account is not verified OR `is_active = false`, THEN `POST /api/v1/auth/login` SHALL reject with 401 Unauthorized and no token is issued.
8. THE SYSTEM SHALL embed the user's `id` and `role` in the JWT payload so downstream RBAC guards don't need a DB round-trip to authorize a request.
9. THE SYSTEM SHALL expire JWTs after a defined TTL (default: 24 hours — confirm/adjust before Phase 11 hardening) and reject expired tokens on protected endpoints.

## User Story: As the system, I need role-based access control so customers, admins, and delivery agents each only reach the endpoints meant for them.

10. WHEN a request carries a valid JWT whose embedded role is not permitted for the target endpoint, THE SYSTEM SHALL reject with 403 Forbidden.
11. WHEN a request to a protected endpoint carries no JWT or an invalid/expired one, THE SYSTEM SHALL reject with 401 Unauthorized.
12. Public endpoints (`POST /auth/register`, `POST /auth/login`, `GET /products`) SHALL NOT require a JWT.
