# Auth — Tasks

- [ ] Implement `OtpSenderPort` interface + console/log dev implementation. (Req 3, [[constitution]])
- [ ] Implement Africa's Talking `OtpSenderPort` implementation (behind env-var config so dev uses the console sender). (Req 3)
- [ ] Implement `POST /auth/register`: create unverified user, generate + store OTP in Redis, send via `OtpSenderPort`. (Req 1–3)
- [ ] Implement `POST /auth/verify-otp`: validate code, mark verified, enforce 5-attempt cap. (Req 4–5)
- [ ] Implement `POST /auth/login`: validate credentials + verified + active, issue JWT. (Req 6–9)
- [ ] Implement `JwtStrategy` + `RolesGuard` + `@Roles()` decorator in `/backend/src/common`, reusable by every other module. (Req 8, 10–12)
- [ ] Write concurrency-agnostic tests: duplicate phone rejected, wrong OTP rejected/capped, expired JWT rejected, wrong-role request rejected with 403. (Req 2, 5, 7, 9–11)
- [ ] Update `/docs` OpenAPI/Swagger with the 3 endpoints above, including the `verify-otp` addition not in the original spec's 7-endpoint list.
