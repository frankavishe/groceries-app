# Admin Web — Requirements

Source: `grocery_app_specifications.pdf` §3C (Inventory Control, Order Fulfillment, Financial Auditing). This is a client spec — it consumes the backend module specs ([[../categories/requirements]], [[../products/requirements]], [[../orders/requirements]], [[../payments/requirements]], [[../delivery/requirements]]) rather than redefining their contracts.

## User Story: As an admin, I want to log in so I can manage the store.

1. WHEN an admin submits valid credentials on the login page, THE SYSTEM SHALL authenticate against [[../auth/requirements]] and store the JWT for subsequent requests.
2. IF a non-`ADMIN` user (e.g. a `CUSTOMER` token) attempts to load the dashboard, THEN THE SYSTEM SHALL redirect to a "not authorized" page rather than rendering admin views.

## User Story: As an admin, I want to manage inventory.

3. THE SYSTEM SHALL provide a category management view: list, create, edit, deactivate (per [[../categories/requirements]]).
4. THE SYSTEM SHALL provide a product management view: list (with search/filter), create, edit, deactivate, and image upload (per [[../products/requirements]]).
5. THE SYSTEM SHALL provide a low-stock alert view surfacing products at or below the configured threshold (per [[../products/requirements]] Req 8).

## User Story: As an admin, I want to track and update order fulfillment.

6. THE SYSTEM SHALL provide an order list view showing all orders with their current status, filterable by status.
7. WHEN an admin selects an order, THE SYSTEM SHALL show its full detail (items, customer, payment status) and allow a status update per the valid transitions in [[../orders/design]].
8. THE SYSTEM SHALL reflect order status changes in near-real-time (via the WebSocket layer in [[../realtime/requirements]], falling back to polling if unavailable).

## User Story: As an admin, I want financial visibility into transactions.

9. THE SYSTEM SHALL provide a transaction view listing `payment_transactions`, filterable by `provider` and `status`.
10. THE SYSTEM SHALL provide a summary breakdown of total transaction volume/count grouped by `payment_provider`.

## User Story: As an admin, I want to assign and track delivery agents.

11. THE SYSTEM SHALL provide a view to assign a `DELIVERY_AGENT` user to a `DISPATCHED` order (per [[../delivery/requirements]]).
