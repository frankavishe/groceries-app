# Admin Web — Design

Implements [[requirements]]. Next.js / React app in `/admin-web`, consuming the NestJS API — no independent business logic duplicated here beyond client-side form validation mirroring backend DTOs.

## Pages / Routes

- `/login` — Req 1–2
- `/categories` — Req 3
- `/products` (list, `/products/new`, `/products/:id/edit`) — Req 4–5
- `/orders` (list, `/orders/:id` detail) — Req 6–8
- `/transactions` — Req 9–10
- `/delivery` (agent assignment view) — Req 11

## Auth Integration

- JWT stored in an httpOnly cookie (not `localStorage`) to reduce XSS token-theft surface, set by a Next.js API route that proxies the login call server-side.
- Middleware checks role claim on every admin route; non-admin redirects to `/unauthorized` (Req 2).

## Data Fetching

- Server components / route handlers call the NestJS API directly using the stored JWT.
- Order list/detail views subscribe to the WebSocket gateway from [[../realtime/design]] for live status updates (Req 8); fall back to a periodic refetch (e.g. every 15s) if the socket disconnects, per [[../constitution]]'s polling-first rule.

## Financial Auditing (Req 9–10)

- Transaction list: paginated table over `GET /api/v1/payments/transactions` (an endpoint to be added in [[../payments/design]] — not in the original spec's 7-endpoint list, needed here).
- Summary view: a grouped aggregate query (count + sum of `amount` per `payment_provider` and `status`) — exposed via a dedicated `GET /api/v1/payments/summary` endpoint rather than computed client-side from potentially large transaction lists.

## List Endpoints Beyond the Public Catalog

Req 3–4's list views need to show deactivated categories/products too (so an admin can re-activate them), but the public `GET /categories` / `GET /products` intentionally filter to active-only. This app calls two admin-only additions instead: `GET /categories/admin` ([[../categories/design]]) and `GET /products/admin` ([[../products/design]]).

## Image Upload UX

- Product/category forms use a file input posting multipart to the upload endpoints in [[../products/design]]; show a preview and progress indicator; on success, populate the `image_url`/`icon_url` field before final form submit.
