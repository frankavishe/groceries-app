# Realtime — Requirements

Source: `grocery_app_specifications.pdf` §1 (architecture diagram shows WebSockets alongside REST), §3C ("Real-time tracking of order lifecycle"). Per [[../constitution]], this is always an enhancement layered on top of working polling, never a hard dependency.

## User Story: As an admin, I want order status changes to appear live in the dashboard without manual refresh.

1. WHEN any order's `status` changes (via [[../orders/requirements]] Req 8 or [[../payments/requirements]] Req 7), THE SYSTEM SHALL broadcast the change (`order_id`, new `status`) to connected admin WebSocket clients.
2. WHEN an admin-web session establishes a WebSocket connection, THE SYSTEM SHALL authenticate it using the same JWT used for REST calls before allowing it to receive broadcasts.
3. IF the WebSocket connection drops, THEN THE SYSTEM (client side) SHALL fall back to periodic polling of `GET /orders` until the socket reconnects — no admin view SHALL depend solely on the socket for correctness.

## User Story: As a customer, I want my order status to update without needing to force-refresh.

4. THE SYSTEM MAY broadcast order-status changes to the customer's own mobile session if connected, but the mobile app's polling-based status checks ([[../mobile-app/requirements]] Req 11) remain the primary, always-correct mechanism regardless of socket availability.
