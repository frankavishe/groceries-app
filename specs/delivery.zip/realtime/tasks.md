# Realtime — Tasks

- [ ] Implement `@WebSocketGateway` in `/backend/src/realtime` with JWT-authenticated handshake. (Req 1–2)
- [ ] Implement `emitOrderStatusChanged` shared helper; call it from `orders.service.ts` and `payments.service.ts`. (Req 1)
- [ ] Implement admin room join on connect. (Req 1–2)
- [ ] Wire admin-web `useOrderSocket` hook with polling fallback on disconnect. (Req 3)
- [ ] Manual test per `PLAN.md` M10 verification: two admin sessions open, change status via API, confirm both update live; kill the socket and confirm polling fallback still reflects changes.
