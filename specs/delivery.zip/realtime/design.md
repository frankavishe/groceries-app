# Realtime — Design

Implements [[requirements]]. Built last (`PLAN.md` Phase 10) — retrofitted onto an already-correct polling-based system, per [[../constitution]].

## Gateway

- NestJS `@WebSocketGateway` in `/backend/src/realtime`, namespace e.g. `/ws/orders`.
- Connection handshake validates the JWT (query param or auth header, per socket.io conventions) using the same `JwtStrategy` as REST ([[../auth/design]]) — reject unauthenticated connections (Req 2).
- Admin clients join a shared room (e.g. `admins`); a future customer-facing use (Req 4) would join a per-user room keyed on `user.id` — not required for MVP admin scope but the room-based design accommodates it without rework.

## Broadcast Trigger

- `orders.service.ts` ([[../orders/design]]) and `payments.service.ts` ([[../payments/design]]) both call a shared `emitOrderStatusChanged(orderId, newStatus)` helper after committing a status transition — single call site pattern avoids scattering `gateway.emit(...)` calls across multiple services.

## Client Fallback (Req 3)

- Admin-web ([[../admin-web/design]]) subscribes to the socket on the order list/detail views; a `useOrderSocket` hook falls back to a 15s `setInterval` refetch if `socket.disconnected` is true for more than a few seconds — the polling path reuses the exact same `GET /orders` call the page would make anyway, so no duplicate logic exists for "get current order state."
