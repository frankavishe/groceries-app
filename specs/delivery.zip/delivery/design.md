# Delivery — Design

Implements [[requirements]]. Extends [[../orders/design]]'s status state machine rather than duplicating it.

## Schema Addition

`orders.assigned_agent_id UUID REFERENCES users(id) ON DELETE SET NULL` — tracked as a "Pending Schema Addition" in [[../database/design]]; add via its own migration when this module starts (Phase 8 of `PLAN.md`), keeping the base schema a faithful match to the original spec PDF until this point.

## Endpoints

| Method | Path | Access | Notes |
|---|---|---|---|
| PATCH | `/api/v1/orders/:id/assign` | Admin | Req 1–3 |
| GET | `/api/v1/delivery/my-orders` | Delivery Agent | Req 4 |
| PATCH | `/api/v1/orders/:id/status` | Delivery Agent (restricted) | Req 5–6, same endpoint as [[../orders/design]] but with an additional guard: if caller role is `DELIVERY_AGENT`, only `DISPATCHED → DELIVERED` on their own assigned order is permitted; the existing `RolesGuard` + status-transition-table checks in [[../orders/design]] still apply first |

## RolesGuard Extension

`PATCH /orders/:id/status` already exists in [[../orders/design]] as admin-only. This module extends its guard to also accept `DELIVERY_AGENT`, but with a narrower allowed-transition set checked in the handler (not just the guard): `DELIVERY_AGENT` + target status `DELIVERED` + `order.assigned_agent_id === currentUser.id` + current status `DISPATCHED` — any other combination for that role is 403, per Req 5–6.

## Non-Goals (per [[../constitution]])

No route optimization, no map view, no earnings/payout tracking, no push notification to the agent on assignment (agent must check `my-orders` — polling is acceptable for this minimal view). All explicitly out of MVP scope.
