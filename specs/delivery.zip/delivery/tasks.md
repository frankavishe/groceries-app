# Delivery — Tasks

- [ ] Add `orders.assigned_agent_id` migration. (supports Req 1)
- [ ] Implement `PATCH /orders/:id/assign` (admin), validating target status and agent role. (Req 1–3)
- [ ] Implement `GET /delivery/my-orders` (agent, own assignments, `DISPATCHED` first). (Req 4)
- [ ] Extend `PATCH /orders/:id/status` guard/handler to accept `DELIVERY_AGENT` for the narrow `DISPATCHED → DELIVERED` self-assigned case. (Req 5–6)
- [ ] Write test: agent cannot set any status other than `DELIVERED`, and cannot act on orders not assigned to them. (Req 6)
- [ ] Build the minimal delivery-agent view in admin-web (per [[../admin-web/requirements]] Req 11) — decide here whether agents get their own lightweight screen or use the same admin-web login scoped by role.
- [ ] Update `/docs` OpenAPI.
