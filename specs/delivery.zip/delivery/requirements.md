# Delivery — Requirements

The `user_role` enum includes `DELIVERY_AGENT`, but the spec PDF describes no delivery-agent workflow anywhere. Per user decision, MVP includes a **minimal** delivery-agent view — not route optimization, not earnings tracking (see [[../constitution]] out-of-scope list).

## User Story: As an admin, I want to assign a delivery agent to a dispatched order.

1. WHEN an authenticated `ADMIN` calls `PATCH /api/v1/orders/:id/assign` with a `DELIVERY_AGENT` user's `id`, THE SYSTEM SHALL record that assignment on the order.
2. IF the target order's `status` is not `PROCESSING` or `DISPATCHED`, THEN THE SYSTEM SHALL reject the assignment with 400 (agents are assigned once an order is being fulfilled, not while still `PENDING`/`PAID`).
3. IF the supplied user `id` does not have `role = DELIVERY_AGENT`, THEN THE SYSTEM SHALL reject with 400.

## User Story: As a delivery agent, I want to see my assigned orders and update their status.

4. WHEN an authenticated `DELIVERY_AGENT` calls `GET /api/v1/delivery/my-orders`, THE SYSTEM SHALL return only orders assigned to them, with status `DISPATCHED` (their active queue) shown first.
5. WHEN an authenticated `DELIVERY_AGENT` calls `PATCH /api/v1/orders/:id/status` to set `status = DELIVERED`, THE SYSTEM SHALL accept it only if that order is assigned to them and currently `DISPATCHED` — otherwise reject with 403.
6. A `DELIVERY_AGENT` SHALL NOT be able to set any status other than `DELIVERED` (they cannot set `PROCESSING`, `PAID`, `CANCELLED`, etc. — those remain admin-only per [[../orders/requirements]] Req 8).
